Also on live box: /exec-daemon/{node,rg,pty.node,cursorsandbox,lib,agent-sdk,tools,canvas-runtime} — omitted from zip due to size (node alone ~120MB).
