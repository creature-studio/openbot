# 助手电脑运行时链路（本机实测）

> 基于 `/usr/local/bin/start-sand-box`、`sand-supervisor`、进程表与端口约定整理。
> `host-main.cjs` / `exec-daemon/index.js` 为打包产物，不是可读源仓库。

## 0. 一句话

聊天客户端 ↔ 网关/平台 ↔ **本机 sand-supervisor** 拉起 **host-main** ↔ 一个或多个 **exec-daemon**（Shell/PTY/Computer-Use/MCP）↔ Chrome 桌面 / 文件系统 / 工具二进制。

## 1. 启动层级（谁拉起谁）

```
容器/镜像入口
  └─ start-sand-box
       ├─ cgroup 初始化（box-cgroups.sh）
       ├─ 桌面栈（Xvfb / 窗口管理 / VNC·noVNC 等，由 desktop supervise 登记）
       ├─ supervise-sand-supervisor
       │    └─ sand-supervisor.mjs（常驻）
       │         ├─ 拉起并监护 host-main.cjs
       │         ├─ 处理 ping / restart / upgrade（读 /tmp/sand-supervisor/command.json）
       │         └─ 桌面健康检查（/tmp/sand-supervisor/desktop-health.json）
       └─ supervise-exec-daemon（至少一个主实例）
            └─ start-exec-daemon → /exec-daemon/exec-daemon serve …
                 └─ node /exec-daemon/index.js serve --port 1337 …
```

端口约定（`start-sand-box` 内嵌 box-contract）：

| 用途 | 端口 |
|------|------|
| 主 exec-daemon HTTP | 1337 |
| 主 exec-daemon PTY WebSocket | 1338 |
| window-router | 1339 |
| fork noVNC | 6081 |
| egress tunnel WS | 8790 |
| egress HTTP CONNECT 代理 | 8791 |
| 各助手 fork exec-daemon 基址 | 14000+（本机见 14002/03/06/08/09…） |
| 对应 PTY | 13602 等 |

## 2. 三个核心进程

### 2.1 sand-supervisor（可读源码，`/usr/local/bin/sand-supervisor*.mjs`）

- 角色：主机监护 + 升级 + 桌面监督。
- 状态：`/tmp/sand-supervisor/status.json`（本机曾见 `hostRunning:true`, `hostVersion:a4658a4`）。
- 数据根：`/home/box/sand-data`；host 目录：`/home/box/sand-host`；入口：`host-main.cjs`。
- 命令种类：`ping` / `restart` / `upgrade`（bundle | image | restart）。
- 会同步 `box-scripts` 到 `/usr/local/bin`（部分镜像自有脚本禁止覆盖）。

### 2.2 host-main（打包：`/home/box/sand-host/host-main.cjs`）

- 角色：这台「助手电脑」总控（sand-host）。
- 由 supervisor 用 `/exec-daemon/node` 启动。
- 旁路 worker：`pdf-worker.js`、`diff-worker.js`、`sand-eval-runner.cjs` 等。
- 负责多智能体数据、浏览器会话协调、把工具调用转到 exec-daemon / Chrome。
- 体积约 25MB，CommonJS 单文件打包，不适合直接阅读。

### 2.3 exec-daemon（打包：`/exec-daemon/index.js`，包名 `@anysphere/exec-daemon-runtime`）

- 启动器：`/exec-daemon/exec-daemon`（bash → 自带 node 跑 index.js）。
- 主实例典型参数：
  `serve --port 1337 --pty-websocket-port 1338 --auth-token local --rg-path /exec-daemon/rg --pty-auth-token local-pty --computer-use-enabled --computer-use-lazy-init --mcp-meta-tool-enabled --origin-cli-enabled`
- 每个助手还可有 fork 实例（1400x），带 `computer-use` / `origin-cli`。
- 同目录工具：自带 `node`、`rg`、`pty.node`、`cursorsandbox`、`gh`、`agent-sdk`、`canvas-runtime` 等。
- 体积约 14MB，webpack 打包。

## 3. 一次「助手干活」的逻辑路径（概念）

```
你在 App 里发消息
  → 平台/网关把工具调用下发到本机 host
  → host-main 选择对应 agent 上下文与 exec-daemon
  → exec-daemon：
       · Shell / 文件：在 /workspace、/home/box 等执行
       · PTY：1338 / 136xx WebSocket 终端
       · Computer-Use：驱动该 agent 的桌面与 Chrome（chrome-profile/Fork-*）
       · MCP meta / Origin CLI：扩展工具面
  → Chrome 经 127.0.0.1:8791 egress 代理出网
  → 结果回传 host → 平台 → 聊天展示
```

数据侧常见目录：

- `/home/box/sand-data`、`/home/box/agent-data`：智能体状态、transcript、secrets 等
- `/home/box/chrome-profile/Fork-*`：各浏览器配置
- `/workspace`：工作区/scratch

## 4. 本包内容

- `host/`：`host-main.cjs` + version + package.json + 部分 worker
- `exec-daemon/`：`index.js`、`package.json`、`exec-daemon` 启动脚本（及说明；完整 runtime 目录过大，主包已含核心入口）
- `supervisor/`：全部 `sand-supervisor*.mjs`
- `boot-scripts/`：`start-sand-box`、`start-exec-daemon`、`supervise-*` 等
- `docs/architecture-zh.md`：本文

## 5. 说明

这些是运行时部署文件，版权归平台方。仅供你在本环境理解架构与本地分析；不要当成开源授权拷贝分发。
